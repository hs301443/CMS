import React from 'react'

const CurriculaPage = () => {
       return (
              <div>CurriculaPage</div>
       )
}

export default CurriculaPage