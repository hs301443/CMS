import React from 'react'

const AffiliateAD = () => {
       return (
              <div>AffiliateAD</div>
       )
}

export default AffiliateAD