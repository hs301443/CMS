import React from 'react'

const LoginHistoryPage = () => {
       return (
              <div>LoginHistoryPage</div>
       )
}

export default LoginHistoryPage