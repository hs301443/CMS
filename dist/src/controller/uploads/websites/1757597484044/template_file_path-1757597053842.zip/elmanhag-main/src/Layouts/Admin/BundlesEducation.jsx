import React from 'react'
import { BundlesPage } from '../../Pages/AllPages'

const BundlesEducation = () => {
  return (
    <>
      <BundlesPage />
    </>
  )
}

export default BundlesEducation