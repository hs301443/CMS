import React from 'react'

const FinalReviews = () => {
       return (
              <div>FinalReviews</div>
       )
}

export default FinalReviews