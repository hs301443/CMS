import React from 'react'

const LiveClassesPage = () => {
       return (
              <div>LiveClassesPage</div>
       )
}

export default LiveClassesPage