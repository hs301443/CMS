import React from 'react'

const MonthsReviewsPage = () => {
       return (
              <div>MonthsReviewsPage</div>
       )
}

export default MonthsReviewsPage