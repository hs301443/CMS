import React from 'react'

const SolveExams = () => {
       return (
              <div>SolveExams</div>
       )
}

export default SolveExams