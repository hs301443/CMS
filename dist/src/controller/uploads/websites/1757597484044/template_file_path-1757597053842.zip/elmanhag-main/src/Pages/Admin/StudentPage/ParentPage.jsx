import React from 'react'

const ParentPage = () => {
       return (
              <div>ParentPage</div>
       )
}

export default ParentPage