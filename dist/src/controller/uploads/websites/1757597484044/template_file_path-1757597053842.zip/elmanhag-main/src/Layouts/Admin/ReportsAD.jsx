import React from 'react'

const ReportsAD = () => {
       return (
              <div>ReportsAD</div>
       )
}

export default ReportsAD