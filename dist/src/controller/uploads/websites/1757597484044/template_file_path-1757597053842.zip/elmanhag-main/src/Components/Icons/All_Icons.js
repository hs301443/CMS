/* Admin Icons */
export { default as Wroning } from "./AdminIcons/Wroning.jsx";
export { default as AffiliateIcon } from "./AdminIcons/AffiliateIcon.jsx";
export { default as DashboardIcon } from "./AdminIcons/DashboardIcon.jsx";
export { default as EducationIcon } from "./AdminIcons/EducationIcon.jsx";
export { default as ExamsIcon } from "./AdminIcons/ExamsIcon.jsx";
export { default as FinancialIcon } from "./AdminIcons/FinancialIcon.jsx";
export { default as HomeWorkIcon } from "./AdminIcons/HomeWorkIcon.jsx";
export { default as LiveIcon } from "./AdminIcons/LiveIcon.jsx";
export { default as MarketingIcon } from "./AdminIcons/MarketingIcon.jsx";
export { default as NoticeBoardIcon } from "./AdminIcons/NoticeBoardIcon.jsx";
export { default as ReportsIcon } from "./AdminIcons/ReportsIcon.jsx";
export { default as RevisionIcon } from "./AdminIcons/RevisionIcon.jsx";
export { default as SettingsIcon } from "./AdminIcons/SettingsIcon.jsx";
export { default as SupportIcon } from "./AdminIcons/SupportIcon.jsx";
export { default as UserIcon } from "./AdminIcons/UserIcon.jsx";
/* Student Icons */
export { default as CurriculaIcon } from "./StudentIcons/CurriculaIcon.jsx";
export { default as DutiesIcon } from "./StudentIcons/DutiesIcon.jsx";
export { default as FinalReviewsIcon } from "./StudentIcons/FinalReviewsIcon.jsx";
export { default as HomeIcon } from "./StudentIcons/HomeIcon.jsx";
export { default as LiveClassesIcon } from "./StudentIcons/LiveClassesIcon.jsx";
export { default as MonthsReviewsIcon } from "./StudentIcons/MonthsReviewsIcon.jsx";
export { default as SolveExamsIcon } from "./StudentIcons/SolveExamsIcon.jsx";
