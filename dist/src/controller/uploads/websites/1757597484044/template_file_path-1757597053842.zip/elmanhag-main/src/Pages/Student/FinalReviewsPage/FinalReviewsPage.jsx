import React from 'react'

const FinalReviewsPage = () => {
       return (
              <div>FinalReviewsPage</div>
       )
}

export default FinalReviewsPage