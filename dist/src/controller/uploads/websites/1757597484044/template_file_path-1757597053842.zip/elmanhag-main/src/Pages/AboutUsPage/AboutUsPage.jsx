import React from 'react'

const AboutUsPage = () => {
       return (
              <div>AboutUsPage</div>
       )
}

export default AboutUsPage