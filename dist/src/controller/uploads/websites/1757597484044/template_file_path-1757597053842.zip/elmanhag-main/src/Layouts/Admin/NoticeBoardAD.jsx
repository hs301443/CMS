import React from 'react'

const NoticeBoardAD = () => {
       return (
              <div>NoticeBoardAD</div>
       )
}

export default NoticeBoardAD