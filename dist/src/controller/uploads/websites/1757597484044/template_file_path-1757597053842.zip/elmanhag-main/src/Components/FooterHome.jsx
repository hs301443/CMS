import React from 'react'

const FooterHome = () => {
       return (
              <>
                     <div className="w-11/12 m-auto flex flex-row-reverse items-center justify-center">FooterHome</div>
              </>
       )
}

export default FooterHome