import React from 'react'

const DutiesPage = () => {
       return (
              <div>DutiesPage</div>
       )
}

export default DutiesPage