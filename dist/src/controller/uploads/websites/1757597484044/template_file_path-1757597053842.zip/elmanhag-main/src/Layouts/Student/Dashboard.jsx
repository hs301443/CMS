import React from 'react'
import DashboardPage from '../../Pages/Student/DashboardPage/DashboardPage'

const Dashboard = () => {
       return (
              <>
                     <DashboardPage />
              </>
       )
}

export default Dashboard