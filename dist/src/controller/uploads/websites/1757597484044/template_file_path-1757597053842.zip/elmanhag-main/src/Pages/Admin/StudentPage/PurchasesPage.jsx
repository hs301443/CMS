import React from 'react'

const PurchasesPage = () => {
  return (
    <div>PurchasesPage</div>
  )
}

export default PurchasesPage