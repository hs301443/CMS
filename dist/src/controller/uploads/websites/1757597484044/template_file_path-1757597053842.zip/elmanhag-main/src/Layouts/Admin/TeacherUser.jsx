import React from 'react'

const TeacherUser = () => {
  return (
    <div>TeacherUser</div>
  )
}

export default TeacherUser