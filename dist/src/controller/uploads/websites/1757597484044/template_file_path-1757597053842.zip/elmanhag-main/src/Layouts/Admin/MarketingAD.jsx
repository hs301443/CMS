import React from 'react'

const MarketingAD = () => {
       return (
              <div>MarketingAD</div>
       )
}

export default MarketingAD