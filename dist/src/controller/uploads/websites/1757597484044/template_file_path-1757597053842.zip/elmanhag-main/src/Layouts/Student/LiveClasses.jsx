import React from 'react'

const LiveClasses = () => {
       return (
              <div>LiveClasses</div>
       )
}

export default LiveClasses