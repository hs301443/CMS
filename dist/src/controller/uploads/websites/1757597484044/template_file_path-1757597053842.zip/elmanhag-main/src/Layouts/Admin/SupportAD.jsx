import React from 'react'

const SupportAD = () => {
       return (
              <div>SupportAD</div>
       )
}

export default SupportAD