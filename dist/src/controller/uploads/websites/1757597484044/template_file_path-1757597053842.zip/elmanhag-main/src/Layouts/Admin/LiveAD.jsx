import React from 'react'

const LiveAD = () => {
       return (
              <div>LiveAD</div>
       )
}

export default LiveAD