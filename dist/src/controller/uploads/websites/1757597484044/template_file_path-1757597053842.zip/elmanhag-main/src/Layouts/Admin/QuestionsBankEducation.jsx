import React from 'react'
import { QuestionsBankPage } from '../../Pages/AllPages'

const QuestionsBankEducation = () => {
  return (
    <>
      <QuestionsBankPage />
    </>
  )
}

export default QuestionsBankEducation