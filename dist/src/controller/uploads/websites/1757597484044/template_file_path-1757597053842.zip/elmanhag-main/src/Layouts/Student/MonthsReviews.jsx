import React from 'react'

const MonthsReviews = () => {
       return (
              <div>MonthsReviews</div>
       )
}

export default MonthsReviews