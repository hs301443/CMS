import React from 'react'

const Duties = () => {
       return (
              <div>Duties</div>
       )
}

export default Duties