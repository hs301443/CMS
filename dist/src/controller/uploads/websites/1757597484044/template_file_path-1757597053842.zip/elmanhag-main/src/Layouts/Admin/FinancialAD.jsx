import React from 'react'

const FinancialAD = () => {
       return (
              <div>FinancialAD</div>
       )
}

export default FinancialAD