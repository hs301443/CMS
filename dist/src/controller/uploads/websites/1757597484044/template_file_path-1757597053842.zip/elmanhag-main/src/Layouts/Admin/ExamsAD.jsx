import React from 'react'

const ExamsAD = () => {
       return (
              <div>ExamsAD</div>
       )
}

export default ExamsAD