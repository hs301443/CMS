import React from 'react'

const BundlesPage = () => {
  return (
    <div>BundlesPage</div>
  )
}

export default BundlesPage