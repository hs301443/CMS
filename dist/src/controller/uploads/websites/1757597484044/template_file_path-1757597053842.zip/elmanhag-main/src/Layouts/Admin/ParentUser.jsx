import React from 'react'

const ParentUser = () => {
       return (
              <div>ParentUser</div>
       )
}

export default ParentUser