import React from 'react'

const AdminUser = () => {
  return (
    <div>AdminUser</div>
  )
}

export default AdminUser