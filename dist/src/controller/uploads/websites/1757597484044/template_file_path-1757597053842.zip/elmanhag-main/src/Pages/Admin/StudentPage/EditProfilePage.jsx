import React from 'react'
import { Outlet } from 'react-router-dom'

const EditProfilePage = () => {
       return (
              <>
                     <Outlet />
              </>
       )
}

export default EditProfilePage