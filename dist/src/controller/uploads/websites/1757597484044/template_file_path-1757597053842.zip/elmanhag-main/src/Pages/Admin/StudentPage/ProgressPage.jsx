import React from 'react'

const ProgressPage = () => {
  return (
    <div>ProgressPage</div>
  )
}

export default ProgressPage