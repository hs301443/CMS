import React from 'react'

const AdminRolesPage = () => {
       return (
              <div>AdminRolesPage</div>
       )
}

export default AdminRolesPage