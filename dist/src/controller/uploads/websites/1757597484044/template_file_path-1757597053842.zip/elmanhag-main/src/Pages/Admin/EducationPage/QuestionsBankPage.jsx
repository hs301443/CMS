import React from 'react'

const QuestionsBankPage = () => {
       return (
              <div>QuestionsBankPage</div>
       )
}

export default QuestionsBankPage