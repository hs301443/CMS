import React from 'react'

const ConectUsPage = () => {
  return (
    <div>ConectUsPage</div>
  )
}

export default ConectUsPage