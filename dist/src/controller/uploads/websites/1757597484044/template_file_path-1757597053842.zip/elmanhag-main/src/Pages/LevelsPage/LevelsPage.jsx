import React from 'react'

const LevelsPage = () => {
       return (
              <div>LevelsPage</div>
       )
}

export default LevelsPage