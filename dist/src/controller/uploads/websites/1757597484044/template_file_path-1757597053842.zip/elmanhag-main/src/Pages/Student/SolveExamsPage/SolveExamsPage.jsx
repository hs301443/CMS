import React from 'react'

const SolveExamsPage = () => {
       return (
              <div>SolveExamsPage</div>
       )
}

export default SolveExamsPage