// a. Types

interface Person {
    name: string;
    age: number;
}

// b. Union Types
let id: number | string;
id = 10;
id = "A123";

// c. Function with typed arguments and return type
function greet(person: Person): string {
    return `Hello, ${person.name}. You are ${person.age} years old.`;
}

// d. Enum in TypeScript
enum Color {
    Red = "RED",
    Green = "GREEN",
    Blue = "BLUE"
}

// e. Generics
function identity<T>(arg: T): T {
    return arg;
}

// f. Decorators 
function Logger(constructor: Function) {
    console.log("Logging...", constructor);
}

@Logger
class Car {
    constructor(public brand: string) {
        console.log("Car created");
    }
}

// g. Modules 
export class Utils {
    static log(message: string) {
        console.log(message);
    }
}

// 2. Class Point2D
class Point2D {
    constructor(public x: number, public y: number) {}

    
    static distance(p1: Point2D, p2: Point2D): number {
        return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    }
}

// 3. Class Point3D extends Point2D
class Point3D extends Point2D {
    constructor(x: number, y: number, public z: number) {
        super(x, y);
    }

        static distance(p1: Point3D, p2: Point3D): number {
        return Math.sqrt(
            Math.pow(p2.x - p1.x, 2) +
            Math.pow(p2.y - p1.y, 2) +
            Math.pow(p2.z - p1.z, 2)
        );
    }
}
const p1 = new Point2D(1, 2);
const p2 = new Point2D(4, 6);
console.log("Distance 2D:", Point2D.distance(p1, p2));

const p3 = new Point3D(1, 2, 3);
const p4 = new Point3D(4, 6, 8);
console.log("Distance 3D:", Point3D.distance(p3, p4));
